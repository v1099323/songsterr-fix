Songsterr

fix songster youtube popup drag and drop system.
